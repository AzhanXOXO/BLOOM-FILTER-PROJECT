/*
 * ============================================================
 *  BLOOM FILTER IMPLEMENTATION IN C++
 *  Project: Analysis of Algorithms (Spring 2026)
 *  Student: Azhan Masood Khawaja | SAP ID: 62914
 *  Instructor: Mr. Muhammad Usman Sharif
 * ============================================================
 *
 *  A Bloom Filter is a space-efficient probabilistic data structure
 *  that tests whether an element is a member of a set.
 *  - FALSE POSITIVES are possible
 *  - FALSE NEGATIVES are NOT possible
 *
 *  Applications: Web caches, databases, spell checkers, networks
 * ============================================================
 */

#include <iostream>
#include <vector>
#include <string>
#include <functional>
#include <chrono>
#include <iomanip>
#include <cmath>
#include <sstream>
using namespace std;

// ============================================================
//  BLOOM FILTER CLASS
// ============================================================
class BloomFilter {
private:
    vector<bool> bitArray;   // The bit array
    int size;                 // Size of bit array (m)
    int numHashes;            // Number of hash functions (k)
    int insertedElements;     // Count of inserted elements

    // ---- Hash Function 1: djb2 style ----
    int hash1(const string& key) {
        unsigned long hash = 5381;
        for (char c : key)
            hash = ((hash << 5) + hash) + c;
        return hash % size;
    }

    // ---- Hash Function 2: FNV-1a style ----
    int hash2(const string& key) {
        unsigned int hash = 2166136261u;
        for (char c : key) {
            hash ^= (unsigned char)c;
            hash *= 16777619u;
        }
        return hash % size;
    }

    // ---- Hash Function 3: sdbm style ----
    int hash3(const string& key) {
        unsigned long hash = 0;
        for (char c : key)
            hash = c + (hash << 6) + (hash << 16) - hash;
        return hash % size;
    }

    // ---- Hash Function 4: polynomial rolling ----
    int hash4(const string& key) {
        unsigned long hash = 0;
        unsigned long p = 31, mod = size;
        unsigned long p_pow = 1;
        for (char c : key) {
            hash = (hash + (c - 'a' + 1) * p_pow) % mod;
            p_pow = (p_pow * p) % mod;
        }
        return (hash + size) % size;
    }

    // Get all hash positions for a key
    vector<int> getHashPositions(const string& key) {
        vector<int> positions;
        int h1 = hash1(key);
        int h2 = hash2(key);
        int h3 = hash3(key);
        int h4 = hash4(key);

        if (numHashes >= 1) positions.push_back(h1);
        if (numHashes >= 2) positions.push_back(h2);
        if (numHashes >= 3) positions.push_back(h3);
        if (numHashes >= 4) positions.push_back(h4);
        return positions;
    }

public:
    // Constructor
    BloomFilter(int m, int k) : size(m), numHashes(k), insertedElements(0) {
        bitArray.assign(m, false);
        cout << "\n[BloomFilter Created]" << endl;
        cout << "  Bit array size (m) = " << m << endl;
        cout << "  Hash functions (k) = " << k << endl;
    }

    // ---- INSERT an element ----
    void insert(const string& element) {
        vector<int> positions = getHashPositions(element);
        for (int pos : positions)
            bitArray[pos] = true;
        insertedElements++;
    }

    // ---- SEARCH / LOOKUP an element ----
    // Returns: true = "possibly in set", false = "definitely NOT in set"
    bool search(const string& element) {
        vector<int> positions = getHashPositions(element);
        for (int pos : positions) {
            if (!bitArray[pos])
                return false;  // Definitely NOT in set
        }
        return true;  // Possibly in set (may be false positive)
    }

    // ---- CLEAR the filter ----
    void clear() {
        fill(bitArray.begin(), bitArray.end(), false);
        insertedElements = 0;
    }

    // ---- Statistics ----
    double getFalsePositiveRate() {
        // Formula: (1 - e^(-k*n/m))^k
        double exponent = -(double)numHashes * insertedElements / size;
        return pow(1.0 - exp(exponent), numHashes);
    }

    int getBitsFilled() {
        int count = 0;
        for (bool b : bitArray) if (b) count++;
        return count;
    }

    void printStats() {
        cout << "\n--- Bloom Filter Statistics ---" << endl;
        cout << "  Elements inserted     : " << insertedElements << endl;
        cout << "  Bit array size (m)    : " << size << endl;
        cout << "  Hash functions (k)    : " << numHashes << endl;
        cout << "  Bits set to 1         : " << getBitsFilled() << endl;
        cout << "  Estimated FP rate     : " << fixed << setprecision(4)
             << getFalsePositiveRate() * 100 << "%" << endl;
    }

    void printBitArray(int limit = 64) {
        cout << "\n--- Bit Array (first " << min(limit, size) << " bits) ---\n";
        for (int i = 0; i < min(limit, size); i++) {
            cout << bitArray[i];
            if ((i + 1) % 8 == 0) cout << " ";
        }
        cout << endl;
    }
};


// ============================================================
//  HELPER: Optimal Bloom Filter Parameters Calculator
// ============================================================
void printOptimalParams(int n, double p) {
    // m = - (n * ln(p)) / (ln(2))^2
    // k = (m/n) * ln(2)
    double m = -(n * log(p)) / (log(2) * log(2));
    double k = (m / n) * log(2);
    cout << "\n=== Optimal Parameters for n=" << n << " elements, FP rate=" << p << " ===" << endl;
    cout << "  Optimal bit array size (m) = " << (int)ceil(m) << " bits" << endl;
    cout << "  Optimal hash functions (k) = " << (int)ceil(k) << endl;
    cout << "  Memory usage               = " << (int)ceil(m) / 8 << " bytes" << endl;
}


// ============================================================
//  TEST CASE 1: Basic Insert & Search
// ============================================================
void testBasic() {
    cout << "\n========================================" << endl;
    cout << "  TEST CASE 1: Basic Insert & Search" << endl;
    cout << "========================================" << endl;

    BloomFilter bf(200, 3);

    // Insert elements
    vector<string> words = {"apple", "banana", "cherry", "date", "elderberry"};
    cout << "\n[Inserting elements...]" << endl;
    for (const string& w : words) {
        bf.insert(w);
        cout << "  Inserted: " << w << endl;
    }

    // Search for inserted elements (should all return true)
    cout << "\n[Searching inserted elements (all should be FOUND)]" << endl;
    for (const string& w : words) {
        bool found = bf.search(w);
        cout << "  Search '" << w << "': " << (found ? "FOUND (correct)" : "NOT FOUND (error)") << endl;
    }

    // Search for non-inserted elements
    vector<string> notInserted = {"fig", "grape", "honeydew", "kiwi"};
    cout << "\n[Searching non-inserted elements (should be NOT FOUND)]" << endl;
    int falsePositives = 0;
    for (const string& w : notInserted) {
        bool found = bf.search(w);
        if (found) falsePositives++;
        cout << "  Search '" << w << "': " << (found ? "FOUND (false positive!)" : "NOT FOUND (correct)") << endl;
    }
    cout << "  False positives: " << falsePositives << "/" << notInserted.size() << endl;

    bf.printStats();
    bf.printBitArray();
}


// ============================================================
//  TEST CASE 2: Spam Email Filter (Real-World Scenario)
// ============================================================
void testSpamFilter() {
    cout << "\n========================================" << endl;
    cout << "  TEST CASE 2: Spam Email Filter" << endl;
    cout << "========================================" << endl;

    BloomFilter spamFilter(500, 4);

    // Known spam emails
    vector<string> spamEmails = {
        "win1million@scam.com",
        "freeprize@lotto.net",
        "nigerian.prince@fake.org",
        "clickhere@phishing.com",
        "cheap.meds@illegal.net"
    };

    cout << "\n[Loading known spam emails into filter...]" << endl;
    for (const string& email : spamEmails) {
        spamFilter.insert(email);
        cout << "  Blocked: " << email << endl;
    }

    // Check incoming emails
    vector<pair<string, bool>> incoming = {
        {"win1million@scam.com", true},       // spam
        {"hello@friend.com", false},           // legit
        {"nigerian.prince@fake.org", true},    // spam
        {"report@university.edu", false},      // legit
        {"cheap.meds@illegal.net", true}       // spam
    };

    cout << "\n[Checking incoming emails...]" << endl;
    for (auto& [email, isActualSpam] : incoming) {
        bool flagged = spamFilter.search(email);
        string verdict = flagged ? "SPAM" : "LEGIT";
        string correctness = (flagged == isActualSpam) ? "[CORRECT]" : "[WRONG]";
        cout << "  " << email << " -> " << verdict << " " << correctness << endl;
    }

    spamFilter.printStats();
}


// ============================================================
//  TEST CASE 3: Performance Benchmark
// ============================================================
void testPerformance() {
    cout << "\n========================================" << endl;
    cout << "  TEST CASE 3: Performance Benchmark" << endl;
    cout << "========================================" << endl;

    vector<int> sizes = {100, 500, 1000};

    for (int n : sizes) {
        BloomFilter bf(n * 10, 3);

        // Time insertion
        auto startInsert = chrono::high_resolution_clock::now();
        for (int i = 0; i < n; i++) {
            bf.insert("element_" + to_string(i));
        }
        auto endInsert = chrono::high_resolution_clock::now();
        double insertTime = chrono::duration<double, micro>(endInsert - startInsert).count();

        // Time lookup
        auto startSearch = chrono::high_resolution_clock::now();
        for (int i = 0; i < n; i++) {
            bf.search("element_" + to_string(i));
        }
        auto endSearch = chrono::high_resolution_clock::now();
        double searchTime = chrono::duration<double, micro>(endSearch - startSearch).count();

        cout << "\n  n = " << setw(5) << n
             << " | Insert: " << setw(10) << fixed << setprecision(2) << insertTime << " us"
             << " | Search: " << setw(10) << searchTime << " us"
             << " | Est. FP: " << setw(6) << setprecision(2) << bf.getFalsePositiveRate() * 100 << "%" << endl;
    }
}


// ============================================================
//  MAIN MENU
// ============================================================
int main() {
    cout << "=============================================" << endl;
    cout << "   BLOOM FILTER - Analysis of Algorithms" << endl;
    cout << "   Student  : Azhan Masood Khawaja" << endl;
    cout << "   SAP ID   : 62914" << endl;
    cout << "   Semester : Spring 2026" << endl;
    cout << "=============================================" << endl;

    // Print optimal parameters
    printOptimalParams(1000, 0.01);   // 1000 elements, 1% FP rate
    printOptimalParams(10000, 0.001); // 10000 elements, 0.1% FP rate

    // Run test cases
    testBasic();
    testSpamFilter();
    testPerformance();

    cout << "\n=============================================" << endl;
    cout << "   All Test Cases Completed!" << endl;
    cout << "=============================================" << endl;

    return 0;
}
